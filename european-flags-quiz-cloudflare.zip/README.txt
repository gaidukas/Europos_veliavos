EUROPEAN FLAGS QUIZ — CLOUDFLARE PAGES UPLOAD

This folder is the production-built static website. It is built for a site hosted at the domain root and does not require a server or database.

UPLOAD TO CLOUDFLARE PAGES (FREE STATIC HOSTING)
1. Sign in to the Cloudflare dashboard.
2. Open Workers & Pages.
3. Choose Create application > Get started > Drag and drop your files.
4. Enter a unique project name.
5. Upload the ZIP file, then choose Deploy site.
6. After deployment, open the provided https://<project-name>.pages.dev address.
7. To update later, create a new deployment and upload a newly built ZIP.

NOTES
- The flag images load from flagcdn.com and fonts load from Google Fonts, so visitors need an internet connection and those services must remain available.
- The game itself is static. It uses no server, account system, database, or Cloudflare Functions.
- Cloudflare's current Pages documentation says static asset requests are free and unlimited on its Free plan. Current limits include 20,000 files per site and 25 MiB per individual asset. Direct dashboard uploads support a ZIP or folder.
- No free host can guarantee permanent service: providers can change their terms or limits. This package is small and uses only static assets, which suits the free tier.

The Replit app source files are not included or modified by this export.
